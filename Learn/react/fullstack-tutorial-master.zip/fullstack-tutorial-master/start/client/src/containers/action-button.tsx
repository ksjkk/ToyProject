import React from 'react';

const ActionButton: React.FC<any> = () => {
  return <div/>;
}

export default ActionButton;