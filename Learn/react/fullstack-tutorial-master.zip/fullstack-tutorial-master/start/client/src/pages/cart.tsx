import React from 'react';
import { RouteComponentProps } from '@reach/router';

interface CartProps extends RouteComponentProps {

}

const Cart: React.FC<CartProps> = () => {
  return <div />;
}

export default Cart;
